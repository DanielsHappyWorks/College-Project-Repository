#include "Vehicle.h"
#include <string>
using namespace std;
Vehicle::Vehicle(string make, Engine engine)
: make(engine), engine(engine)
{
}
Vehicle::~Vehicle()
{
}
void Vehicle::print() const
{
	cout << "Make:" << make << endl;
	engine.print();
}
bool Vehicle::operator==(const Vehicle& other)
{
	return make == other.getMake()
		&& (engine == other.getEngine());
}
