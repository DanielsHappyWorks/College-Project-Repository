#include "Engine.h"
#include <string>
using namespace std;
Engine::Engine() : cc(1000), weight(200), type(0)
{
}
Engine::Engine(int cc, float weight, int type)
: cc(cc), weight(weight), type(type)
{
}
Engine::~Engine()
{
}

void Engine::print() const
{
	cout << Engine::to_string() << endl;
}
string Engine::to_string() const
{
	return "CC:" + std::to_string(cc) 
		+ ", Weight:" + std::to_string(weight)
		+ ", Type: " + std::to_string(type);
}
Engine::operator std::string() const
{
	return "CC:" + std::to_string(cc)
		+ ", Weight:" + std::to_string(weight)
		+ ", Type: " + std::to_string(type);
}
bool Engine::operator==(const Engine& other)
{
	return (cc == other.getCC())
		&& (weight == other.getWeight())
		&& (type == other.getType());
}

//bool Engine::equals(Engine& other) const
//bool Engine::equals(Engine other) const
//bool Engine::equals(const Engine& other)
bool Engine::equals(Engine other)
{
	return (getCC() == other.getCC())
		&& (getWeight() == other.getWeight())
		&& (getType() == other.getType());
}








