#include "Engine.h"
class Vehicle
{
public:
	Vehicle();
	Vehicle(std::string make, Engine engine);
	~Vehicle();
	void print() const;
	bool operator==(const Vehicle& other);
	std::string getMake() const { return make; }
	Engine getEngine() const { return engine; }
	//<<, to_string, string(), other operators
private:
	std::string make;
	Engine engine;
};