#include "Vehicle.h"
#include <vector>
#include <algorithm>
using namespace std;
bool compareByEngineCC(const Vehicle& v1, const Vehicle& v2);
int main()
{
	vector<Vehicle> vehicleVector;
	Engine e1(3200, 120, 0);
	Vehicle v1("triumph triple r", e1);

	Engine e2(1600, 180, 0); 
	Vehicle v2("kawasaki ninja", e2);

	vehicleVector.push_back(v1);
	vehicleVector.push_back(v2);

	sort(begin(vehicleVector), end(vehicleVector), compareByEngineCC);

	for (Vehicle v : vehicleVector)
		v.print();
	system("pause");
	return 0;
}
bool compareByEngineCC(const Vehicle& v1, const Vehicle& v2)
{
	if (v1.getEngine().getCC() <= v2.getEngine().getCC())
		return true;
	else
		return false;
}


