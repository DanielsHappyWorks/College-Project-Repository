#include <iostream>
class Engine
{
public:
	Engine();
	Engine(int cc, float weight, int type);
	~Engine();
	void setCC(int cc) { Engine::cc = cc; }
	void setWeight(float weight) { Engine::weight = weight; }
	void setType(int type) { Engine::type = type; }
	
	int getCC() const { return cc; }
	float getWeight() const { return weight; }
	int getType() const { return type; }
	void print() const;
	
	bool equals(Engine other);
	bool operator==(const Engine& other);

	std::string to_string() const;
	operator std::string() const;

	friend std::ostream& operator<<(
		std::ostream& stream, Engine& engine);

private:
	int cc; //1100, 1600, 2000
	float weight;
	int type; //diesel, petrol, hybrid
};